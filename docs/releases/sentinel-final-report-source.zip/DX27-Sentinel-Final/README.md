# DX27 Sentinel 最终报告源码包

本包仅含运行报告需要的软件和协议，不含个人数据、采集记录或虚拟环境。

在本目录打开 PowerShell，首次执行：

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[research-report]"
```

随后双击 `deploy\sentinel\open-report.cmd`。
每次打开本地网页都会检查 FactSet 与 Yardeni，并比较上次报告。
完整说明：`docs/operations/sentinel-research-report.md`。
现有采集任务与数据请保留在原部署；本包使用自己的报告目录。
