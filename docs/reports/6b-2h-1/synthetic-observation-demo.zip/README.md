# 合成报告展示样例

所有数值均由离线公式生成，不是真实市场数据。

双击 synthetic-market-observation.html 查看正常样例；degraded-synthetic-market-observation.html 展示最新 SPY 采集失败。

日期固定为 2026-10-09，仅用于展示。原始 payload 和 capture store 不在此包内。本样例不证明真实数据覆盖率、预测有效性或生产准入。

在仓库中复现：

```bash
python -m runners.standalone.sentinel_observation_example --output-directory work/new-synthetic-demo
```
